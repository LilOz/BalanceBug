R = readtable('Real.xlsx');

hold on
VR = R(:,1);
VR = table2array(VR);

IR = R(:,2);
IR = table2array(IR);

plot(VR,IR.*VR,"Color",[0/255,106/255,0/255],"LineWidth",3);
ylabel("Power","FontSize",16);
xlabel("Voltage","FontSize",16);
title("Single Panel Cloudy Characterisation","FontSize",16);


% 
% coefficients_top = polyfit(VR(3:13), IR(3:13), 1);
% 
% xFit_top = linspace(min(VR(3:13)),max(VR(3:13))+0.225,11);
% yFit_top = polyval(coefficients_top,xFit_top);
% 
% plot(xFit_top,yFit_top,"Color",[41/255,120/255,181/255],"LineStyle","--","LineWidth",3);
% 
% coefficients_bottom = polyfit(VR(14:21), IR(14:21), 1);
% 
% xFit_bottom = linspace(min(VR(14:21))-0.025,max(VR(14:21)),9);
% yFit_bottom = polyval(coefficients_bottom,xFit_bottom);
% 
% plot(xFit_bottom,yFit_bottom,"Color",[41/255,120/255,181/255],"LineStyle","--","LineWidth",3);


hold off

E = readtable('Emulated.xlsx');

figure;
hold on
VR = E(:,1);
VR = table2array(VR);

IR = E(:,2);
IR = table2array(IR);
%[226/255,106/255,46/255]
plot(VR,IR.*VR,"Color",[0/255,106/255,0/255],"LineWidth",3);
ylabel("Power","FontSize",16);
xlabel("Voltage","FontSize",16);
title("Single Panel Full Power Emulation","FontSize",16);




hold off


